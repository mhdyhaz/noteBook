<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">

<style>
   
   
   .footer{
    position: fixed;
      left: 0;
      background: linear-gradient(0deg, rgb(211, 216, 230) 0%, rgb(125, 119, 168) 100%);
      bottom: 0;
      width: 100%;
      color: white;
      text-align: center;
        padding: 3px;

   
   } 
    #id-p{
       color: black;
        font-size: 20px;
        text-align: center;
        font-family: initial;
    }
</style>
</head>




<body>

    <div class="footer">
        <p id="id-p" > TTFEO</p>
    </div>



</body>

</html>