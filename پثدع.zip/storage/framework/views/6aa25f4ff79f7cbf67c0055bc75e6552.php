<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
 
        
        .button-container {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .button-container button {
            background-color: rgb(11, 11, 100);
            width: 100px;
            height: 50px;
            color: white;
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 13px 0;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-family: initial;
        }

        .button-container button:hover {
            background-color:  rgb(11, 11, 100);
    </style>
</head>
<body>
    <div class="button-container">
        

        <?php $__env->startSection('title', 'Home Page'); ?>
        
        <?php $__env->startSection('content'); ?>
        <div class="button-container">
            <button onclick="window.location.href='<?php echo e(route('Dashborde.login')); ?>'">Login</button>
            <button onclick="window.location.href='<?php echo e(route('Dashborde.register')); ?>'">Register</button>
        </div>
        <?php $__env->stopSection(); ?>
        
    </div>
</body>
</html>

<?php echo $__env->make('Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mahdyeh/Desktop/Menu/resources/views/Dashborde/home.blade.php ENDPATH**/ ?>